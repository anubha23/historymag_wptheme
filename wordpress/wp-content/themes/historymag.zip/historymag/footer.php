</div>
<hr>

      <footer>
        <p>&copy; Indian History Collective 2016</p>
      </footer>

    </div> <!-- /container -->


 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	
	<?php wp_footer(); ?>
  </body>
</html>