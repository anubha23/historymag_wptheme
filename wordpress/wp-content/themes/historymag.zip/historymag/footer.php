</div>

<hr />
<center>
<div id="footer">
<p>
<p>&copy; Indian History Collective 2016</p>
<br />
</p>
</div>
</center>

    </div> <!-- /container -->

	
	<?php wp_footer(); ?>
  </body>
</html>