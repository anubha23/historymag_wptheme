
  <?php get_header(); ?>
  <div class="container">
  
 
  
	<div class="row">
  
		<div class="col-md-4">
		<h3> <span class="label label-default">TOP STORIES</span></h3>
		<br/>
		<blockquote>‘We are still using a
completely outdated
understanding of
history and methods
of teaching it. The
emphasis is on dates
and events’

</blockquote>

-Ranabir Chakravarti interviews
historian Romila Thapar,
Professor Emeritus, Jawaharlal
Nehru University
  
		</div>
  
		<div class="col-md-8">
			<a href="#" class="thumbnail">
				<img src="http://placekitten.com/500/500" alt="top_story">
			</a>
		</div>
  
	</div>
	
	<div class="row">
	<div class="col-md-12">
	<h3> <span class="label label-default">FEATURED</span></h3>
	</div>
	</div>
	
	<div class="row">
  
		<div class="col-md-6">
		<br/>
		<a href="" class="thumbnail">
				<img src="http://placekitten.com/400/400" alt="top_story">
			</a>
		
		<blockquote>‘We are still using a
completely outdated
understanding of
history and methods
of teaching it. The
emphasis is on dates
and events’

</blockquote>

-Ranabir Chakravarti interviews
historian Romila Thapar,
Professor Emeritus, Jawaharlal
Nehru University
  
		</div>
  
		<div class="col-md-3" style="border-right:2px solid #eeeeee;">
		<br/>
			<a href="#" class="thumbnail">
				<img src="http://placekitten.com/200/150" alt="top_story">
			</a>
			<p style="font-size:17.5px">We are still using a
completely outdated
understanding of
history and methods
of teaching it. The
emphasis is on dates
and events.</p>
<p style="font-size:15px">
Ranabir Chakravarti interviews
historian Romila Thapar,
Professor Emeritus, Jawaharlal
Nehru University
</p>
		</div>
		
		<div class="col-md-3">
		<br/>
			<a href="#" class="thumbnail">
				<img src="http://placekitten.com/200/150" alt="top_story">
			</a>
			<p style="font-size:17.5px">We are still using a
completely outdated
understanding of
history and methods
of teaching it. The
emphasis is on dates
and events.</p>
<p style="font-size:15px">
Ranabir Chakravarti interviews
historian Romila Thapar,
Professor Emeritus, Jawaharlal
Nehru University
</p>

		</div>
  
	</div>
	
	<div class="row">
	<div class="col-md-12">
	<h3> <span class="label label-default">ARCHIVE</span></h3>
	</div>
	</div>
	
	<div class="row">
	<br/>
	<div class="col-md-3" style="border-right:2px solid #eeeeee;">
	
		<a href="#" class="thumbnail">
				<img src="http://placekitten.com/200/150" alt="top_story">
		</a>
		<span style="color:#d02128;font-size:17.5px;">INDIAN HISTORY</span><br/>
		<p style="font-size:17.5px">We are still using a
completely outdated
understanding of
history and methods
of teaching it. The
emphasis is on dates
and events.</p>

	</div>
	
	<div class="col-md-3" style="border-right:2px solid #eeeeee;">

		<a href="#" class="thumbnail">
				<img src="http://placekitten.com/200/150" alt="top_story">
		</a>
		<span style="color:#d02128;font-size:17.5px;">INDIAN HISTORY</span><br/>
		<p style="font-size:17.5px">We are still using a
completely outdated
understanding of
history and methods
of teaching it. The
emphasis is on dates
and events.</p>	
	</div>
	
	<div class="col-md-3" style="border-right:2px solid #eeeeee;">
	
		<a href="#" class="thumbnail">
				<img src="http://placekitten.com/200/150" alt="top_story">
		</a>
		<span style="color:#d02128;font-size:17.5px;">INDIAN HISTORY</span><br/>
		<p style="font-size:17.5px">We are still using a
completely outdated
understanding of
history and methods
of teaching it. The
emphasis is on dates
and events.</p>
	</div>
	
	<div class="col-md-3" style="border-right:2px solid #eeeeee;">
	
		<a href="#" class="thumbnail">
				<img src="http://placekitten.com/200/150" alt="top_story">
		</a>
		<span style="color:#d02128;font-size:17.5px;">INDIAN HISTORY</span><br/>
		<p style="font-size:17.5px">We are still using a
completely outdated
understanding of
history and methods
of teaching it. The
emphasis is on dates
and events.</p>
	</div>
	</div>

   <?php get_footer(); ?>